<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            PermissionSeeder::class,
            RoleSeeder::class,
            MasterDataSeeder::class,
            CompanySeeder::class,
            DemoDataSeeder::class,
            HrDemoSeeder::class,
            AiSkillSeeder::class,
            ComprehensiveDemoSeeder::class,
            DemoCredentialSeeder::class,
            RagPipelineSeeder::class,
        ]);
    }
}
