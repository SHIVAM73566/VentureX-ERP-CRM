<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

#[Fillable(['user_id', 'password'])]
class PasswordHistory extends Model
{
    protected $table = 'password_history';

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
